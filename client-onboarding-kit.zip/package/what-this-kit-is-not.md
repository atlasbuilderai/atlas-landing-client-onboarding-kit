# What This Kit Is Not

Client Onboarding Kit is intentionally focused.

It is not:
- a full CRM
- an invoicing platform
- project management software
- a client messaging app
- a complete agency operating system

It is a structured onboarding kit designed to improve the period between:
- signed client
- onboarding/admin completion
- kickoff-ready project

That narrow scope is intentional.

The value of this product is clarity, repeatability, and faster onboarding — not trying to replace every other tool in your business.
