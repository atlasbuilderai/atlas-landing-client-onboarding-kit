# Kickoff Agenda Template

## Meeting Objective
Use this kickoff meeting to align on goals, scope, timeline, responsibilities, and the immediate next steps.

## Recommended Agenda
### 1. Welcome + introductions
- Confirm who is involved
- Confirm roles and main points of contact

### 2. Project goal recap
- What are we trying to accomplish?
- What does success look like?
- What is the priority outcome?

### 3. Scope + deliverables
- Confirm agreed deliverables
- Clarify boundaries / what is not included
- Confirm major milestones

### 4. Timeline
- Confirm start date
- Confirm key deadlines
- Confirm review / feedback windows

### 5. Inputs needed from client
- Files
- Access / logins
- Approvals
- Stakeholder availability

### 6. Communication process
- Preferred communication channel
- Response-time expectations
- Meeting cadence
- Escalation path if blocked

### 7. Risks / blockers
- Any dependencies?
- Any missing assets or information?
- Any timeline concerns?

### 8. Immediate next steps
- What happens next?
- Who owns each next action?
- When is the next checkpoint?

## Kickoff Summary Template
After the meeting, send a summary covering:
- confirmed goals
- scope
- timeline
- open items
- next steps
- owners
