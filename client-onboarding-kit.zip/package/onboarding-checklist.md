# Master Onboarding Checklist

## Stage 1 — Deal Closed
- [ ] Mark client as won / confirmed
- [ ] Create new client record
- [ ] Assign owner
- [ ] Confirm service/package purchased
- [ ] Confirm start date

## Stage 2 — Welcome + Admin
- [ ] Send welcome email
- [ ] Send contract
- [ ] Send invoice or payment request
- [ ] Confirm payment status
- [ ] Request required assets/access

## Stage 3 — Internal Setup
- [ ] Create client portal page
- [ ] Add timeline / next steps
- [ ] Add links, files, and key contacts
- [ ] Prepare kickoff agenda
- [ ] Add internal notes / risk flags

## Stage 4 — Kickoff Prep
- [ ] Confirm kickoff date and time
- [ ] Confirm attendees
- [ ] Confirm required materials received
- [ ] Send kickoff reminder
- [ ] Final internal review

## Stage 5 — Onboarding Complete
- [ ] Kickoff completed
- [ ] Send summary / next steps
- [ ] Mark onboarding complete
- [ ] Move client into delivery workflow
