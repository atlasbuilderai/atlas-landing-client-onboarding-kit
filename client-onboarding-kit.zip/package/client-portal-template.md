# Client Portal Template

## Welcome
Welcome to the project. This page is your central place for everything related to onboarding and next steps.

## What Happens Next
1. We confirm all required inputs
2. We finalize admin items
3. We prepare for kickoff
4. We begin delivery

## Current Status
- Status:
- Next step:
- Waiting on:
- Kickoff date:

## What We Need From You
- [ ] Required files
- [ ] Access/logins
- [ ] Approvals
- [ ] Scheduling confirmation

## Important Links
- Contract:
- Invoice / payment:
- Shared folder:
- Meeting link:
- Project contacts:

## Questions
If anything is unclear, reply here / by email and we’ll keep everything moving.
