# Handoff to Delivery Template

## Purpose
Use this template when onboarding is complete and the project is ready to move into active delivery.

## Client Summary
- Client name:
- Company:
- Main contact:
- Service/package:
- Start date:

## Onboarding Status
- Contract complete:
- Payment status:
- Kickoff complete:
- Required assets received:
- Access/logins received:
- Portal set up:

## Confirmed Goals
- Primary goal:
- Success metric:
- Priority deliverables:

## Important Context
- Client preferences:
- Communication expectations:
- Risks / blockers:
- Stakeholders involved:

## Active Links
- Client portal:
- Shared folder:
- Contract:
- Invoice/payment:
- Meeting notes:

## Delivery Notes
- Immediate next action:
- Owner:
- First delivery milestone:
- Pending approvals:

## Final Handoff Check
- [ ] Delivery team has required context
- [ ] Missing items identified
- [ ] Next step assigned
- [ ] Client knows what happens next
