# Example Client Setup

## Sample Client
- Client name: BrightPath Studio
- Company: BrightPath Studio
- Main contact: Alyssa Reed
- Service: Website redesign
- Package: 6-page redesign + launch support
- Start date: April 8
- Kickoff date: April 11

## Intake Summary
### Business goal
Improve conversion rate on the services page and modernize the brand presentation.

### Success metric
Higher inbound leads from the website and improved clarity around service offerings.

### Required assets
- current sitemap
- brand logo files
- copy deck
- analytics access
- hosting access

## Onboarding Checklist Snapshot
- [x] Client marked won
- [x] Welcome email sent
- [x] Contract sent
- [x] Contract signed
- [x] Invoice sent
- [x] Payment received
- [x] Asset request sent
- [x] Kickoff date confirmed
- [ ] Kickoff completed
- [ ] Onboarding marked complete

## Client Portal Example
### Welcome
Welcome to your website redesign project. This page is the home base for onboarding and next steps.

### Current status
- Status: Kickoff scheduled
- Next step: Kickoff meeting on April 11
- Waiting on: Final copy deck

### What we need from you
- [ ] Final website copy
- [x] Brand files
- [x] Hosting access
- [x] Analytics access

### Important links
- Contract: [link]
- Invoice: [link]
- Shared folder: [link]
- Kickoff meeting: [link]

## Example Welcome Email
Subject: Welcome — here’s what happens next

Hi Alyssa,

Excited to get started on the BrightPath Studio redesign.

Here’s what happens next:
1. We’ll finish collecting the remaining onboarding items
2. We’ll meet for kickoff on April 11
3. We’ll move into the first design milestone after kickoff

Your portal is here:
[Portal Link]

Thanks,
[Your Name]
