# Email Templates

## 1. Welcome Email
Subject: Welcome — here’s what happens next

Hi [Client Name],

Excited to get started. I’ve set up your onboarding process so everything is clear from day one.

Here’s what happens next:
1. We’ll confirm the remaining onboarding details
2. We’ll collect any assets or access needed
3. We’ll finalize kickoff

You can find the key next steps here:
[Client Portal Link]

Thanks,
[Your Name]

---

## 2. Contract Sent
Subject: Contract for review

Hi [Client Name],

I’ve sent over the contract for review. Once that’s completed, we’ll move straight into the remaining onboarding steps.

Link:
[Contract Link]

Thanks,
[Your Name]

---

## 3. Invoice / Payment Reminder
Subject: Quick payment reminder

Hi [Client Name],

Just a quick reminder that the invoice for this project is here:
[Invoice Link]

Once that’s handled, we’ll be fully clear to move into kickoff.

Thanks,
[Your Name]

---

## 4. Asset Request
Subject: A few items we need before kickoff

Hi [Client Name],

To keep onboarding moving, please send the following items:
- [Item 1]
- [Item 2]
- [Item 3]

You can upload or share them here:
[Link]

Thanks,
[Your Name]

---

## 5. Kickoff Confirmed
Subject: Kickoff confirmed

Hi [Client Name],

Your kickoff is confirmed for [Date/Time].

Meeting link:
[Meeting Link]

We’ll cover:
- goals
- timeline
- deliverables
- communication

Looking forward to it,
[Your Name]

---

## 6. Onboarding Complete
Subject: Onboarding complete — next steps

Hi [Client Name],

We’ve completed onboarding and everything is ready to move into delivery.

Next steps:
- [Next Step 1]
- [Next Step 2]

Your portal remains here:
[Portal Link]

Thanks,
[Your Name]
