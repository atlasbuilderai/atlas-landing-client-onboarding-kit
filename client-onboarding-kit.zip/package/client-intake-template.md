# Client Intake Template

## Basic Info
- Client name:
- Company:
- Main contact:
- Email:
- Phone:
- Website:

## Service Details
- Service purchased:
- Package / tier:
- Price:
- Start date:
- Target kickoff date:

## Project Context
- Business goal:
- Primary problem to solve:
- Success metric:
- Priority deliverables:

## Assets / Access Needed
- Brand assets:
- Logins / credentials needed:
- Existing files / docs:
- Stakeholders involved:

## Communication Preferences
- Preferred channel:
- Response-time expectations:
- Meeting cadence:

## Internal Notes
- Risks / blockers:
- Special requests:
- Upsell potential:
