# SOP / Reuse Guide

## Purpose
Use this system the same way every time a new client signs.

## Reuse Process
1. Duplicate the base onboarding workspace
2. Rename it with the new client name
3. Fill intake details
4. Create portal page from template
5. Send welcome email
6. Work through checklist in order
7. Mark onboarding complete after kickoff prep is done

## Rules
- Keep all key onboarding info in one place
- Do not skip payment / contract checkpoints
- Do not schedule kickoff before required inputs are clear
- Keep the client-facing page updated so the client knows what happens next

## Customization Guidance
Customize only:
- service details
- requested assets
- timeline
- kickoff agenda
- communication expectations

Leave the overall workflow structure the same unless you have a strong reason to change it.

## Future Upgrades
Later versions can add:
- automation
- status updates
- reminders
- portal generation
- invoicing integrations
