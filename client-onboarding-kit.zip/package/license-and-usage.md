# License & Usage

## What you can do
You can use Client Onboarding Kit for your own business operations.

You can:
- adapt the templates to your workflow
- duplicate the system for your own clients
- customize the files for your own service business

## What you cannot do
You may not:
- resell the kit as your own product
- redistribute the files publicly
- share the full package with other businesses as a free download
- repackage it for sale without permission

## Notes
This is a practical operations kit intended for end-user implementation inside a service business.
