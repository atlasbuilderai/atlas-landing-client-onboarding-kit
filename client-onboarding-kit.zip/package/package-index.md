# Client Onboarding Kit — Package Index

## Core Guides
- `start-here.md` — orientation, setup order, and intended use
- `quickstart-guide.md` — fast setup instructions
- `buyer-checklist.md` — first-use checklist after purchase
- `implementation-options.md` — how to use the kit in different tools
- `what-this-kit-is-not.md` — scope clarification
- `license-and-usage.md` — permitted use and restrictions

## Core Workflow Assets
- `onboarding-checklist.md` — master onboarding checklist
- `client-intake-template.md` — intake template
- `client-portal-template.md` — client-facing portal structure
- `email-templates.md` — reusable onboarding email templates
- `kickoff-agenda-template.md` — kickoff meeting structure
- `handoff-to-delivery-template.md` — handoff template
- `sop-reuse-guide.md` — guide for reusing the system consistently

## Examples & Delivery
- `example-client-setup.md` — worked example of the kit in use
- `customer-delivery-preview.md` — preview of what the customer receives
- `customer-delivery-email.md` — draft delivery email copy

## Recommended Reading Order
1. `start-here.md`
2. `quickstart-guide.md`
3. `buyer-checklist.md`
4. `implementation-options.md`
5. `onboarding-checklist.md`
6. `example-client-setup.md`
