# Buyer Checklist

Use this quick checklist after purchase.

## First 30 Minutes
- [ ] Read Start Here
- [ ] Read Quickstart Guide
- [ ] Choose implementation tool (Notion, Airtable, Docs, etc.)
- [ ] Review the Master Onboarding Checklist
- [ ] Review the Example Client Setup

## Setup
- [ ] Create your base onboarding workspace
- [ ] Add the Client Intake Template
- [ ] Add the Client Portal Template
- [ ] Add the Email Templates
- [ ] Add the Kickoff Agenda Template
- [ ] Add the Handoff to Delivery Template

## First Real Use
- [ ] Duplicate the system for a real client
- [ ] Customize the intake questions
- [ ] Customize the portal and email templates
- [ ] Run the onboarding checklist
- [ ] Note anything to improve for the next client
